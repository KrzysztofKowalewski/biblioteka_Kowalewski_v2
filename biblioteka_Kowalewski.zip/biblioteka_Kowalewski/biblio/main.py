from manage_book import *
from manage_customer import *
from datetime import date
import random
if __name__ == '__main__':
    addbook(random.randint(104,1000),'Writer','Ogniem i mieczem', '500', '1861-02-01', date.today())
    #addcustomer(random.randint(1000,9999),'Kamil Kajak','kajakowski321@gmail.com','032123456', date.today(), date.today(), 'Kwiatowa', 'Bialystok','Poland')
    #rent_book(6630,'Wyklady z kombinatoryki')
    #rent_books(1972,['The Codebreakers','The Object-Oriented Thought Process','Programming structures'])
    #return_book(1972, 'The Codebreakers')
    #delbook_id(139)
    #delbook_title('Wyklady z kombinatoryki')
    #delcust_name('Marian Mariuszowski')


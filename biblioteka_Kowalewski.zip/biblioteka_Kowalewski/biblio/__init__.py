'''
Moduł manage_book.py odpowiada za wszystkie funkcje związane z dodawaniem i usuwaniem książek do bazy danych
Jest w nim funkcja addbook do dodawania ksiażęk oraz funkcje delbook_id i delbook_title które usuwają książki po id lub po tytule

Moduł manage_customer.py odpowiada za to za funkcje związane z dodawaniem i usuwaniem użytkowników:

add_customer - dodaje użytkwonika do bazy danych
delcust_id - usuwa użytkownika po id
delcust_name - usuwa użytkownika po nazwie

ale też za czynności z nimi związane, takie jak oddawanie książek:

rent_book - wypożycza książkę przez konkretnego użytkownika
rent_books - wypożycza kilka książek naraz
return_book - zwraca książkę do biblioteki przez konkretnego klienta


'''